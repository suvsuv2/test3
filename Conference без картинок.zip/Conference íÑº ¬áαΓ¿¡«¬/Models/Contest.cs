﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conference.Models
{
    internal class Contest
    {
        public static MaincontextM Context { get; } = new MaincontextM();
    }
}

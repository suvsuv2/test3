﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManadgerr.Models
{
    internal class Constants
    {
        public static MainContextz Context { get; } = new MainContextz();
    }
}
